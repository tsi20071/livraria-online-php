<?php
	$busca = strtoupper($_GET['busca']);

	$query = 'SELECT codigo, titulo, autor, editora, preco FROM livros WHERE UPPER(titulo) LIKE \'%' . $busca . '%\' OR UPPER(autor) LIKE \'%' . $busca . '%\' OR UPPER(editora) LIKE \'%' . $busca . '%\' ORDER BY codigo DESC';
	$resultado = mysqli_query($conexao, $query);
	
	if ($resultado->num_rows > 0)
	  include_once('inserirdados.php');
	else
	  echo '<span>N&atilde;o foram encontrados livros como resultado da sua busca.</span>';
?>