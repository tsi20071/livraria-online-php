<?php
	$conexao = mysqli_connect('localhost', 'root', '', 'projetophp'); // CONECTA O BANCO PRA USAR EM TODA A P�GINA
	include_once('checatitulo.php'); // IMPORTA O ARQUIVO PHP QUE CHECA O T�TULO DA P�GINA
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Livraria Online</title>
<link href="fontes.css" rel="stylesheet" type="text/css" />
<link href="estilos.css" rel="stylesheet" type="text/css" />
<link href="visualizalivro.css" rel="stylesheet" type="text/css" />
<link href="inserirdados.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div class="cabecalho">
  <div class="cabecalho-esquerdo"><img src="imagens/site-logo.png" width="160" height="80" />&nbsp;<span>Livraria Online</span></div>
  <div class="cabecalho-direito">
    <form method="post" action="login.php">
      <table cellpadding="0" cellspacing="0" width="290px">
        <tr>
          <td width="160px"><label>Usu&aacute;rio</label></td><td width="160px" style="padding-left: 10px;"><label>Senha</label></td>
        </tr>
        <tr>
          <td width="160px"><input type="text" name="usuario" id="usuario" class="campo" /></td><td width="160px" style="padding-left: 10px;"><input type="password" name="senha" id="senha" class="campo" /></td>
        </tr>
        <tr>
          <td colspan="2" align="right"><input type="submit" value="Acessar" class="botao" /></td>
      </table>
    </form>
  </div>
</div>
<div class="conteudo">
  <div class="menu">
    <ul class="categorias">
      <li class="cabecalho-menu">LIVRARIA</li>
      <?php
	  $query = 'SELECT * FROM menuprincipal WHERE STATUS=0 OR STATUS=2';
	  $resultado = mysqli_query($conexao, $query);
	  
	  while($dados = mysqli_fetch_array($resultado)) {
		  echo '<li class="item-menu"><a href="';
		  echo $dados['link'];
		  echo '" title="' . $dados['alternativo'] . '">' . $dados['descricao'] . '</a></li>';
	  }
	  ?>
      <li class="cabecalho-menu">CATEGORIAS</li>
      <?php
	  $query = 'SELECT * FROM categorias ORDER BY descricao ASC';
	  $resultado = mysqli_query($conexao, $query);
	  
	  while($dados = mysqli_fetch_array($resultado)) {
		  echo '<li class="item-menu"><a href="index.php?categoria=' . $dados['codigo'] . '&titulo=categorias';
		  echo '" title="' . $dados['alternativo'] . '">' . $dados['descricao'] . '</a></li>';
	  }
	  ?>
    </ul>
  </div>
  <div class="menu-aux">
    <span class="busca">BUSCAR LIVROS</span>
    <form method="get" action="index.php">
      <input name="busca" id="busca" type="text" style="width: 150px;" />
      <input type="hidden" name="titulo" value="busca" />
      <input type="submit" value="Buscar" class="botao" />
    </form>
  </div>
  <div class="centro">
    <div class="pagina"><?php echo $titulo; ?></div><?php
	if (isset($_GET['categoria']))
	  include_once('categorias.php');
	elseif (isset($_GET['busca']))
		  include_once('buscar.php');
	elseif (isset($_GET['visualizalivro'])) 
		  include_once('visualizalivro.php');
	else
		include_once('destaques.php');
	?></div>
  <div class="clearer"></div>
</div>
</body>
</html>
<?php
mysqli_close($conexao);
?>