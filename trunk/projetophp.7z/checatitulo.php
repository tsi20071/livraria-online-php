<?php
	if (isset($_GET['titulo'])) // TODO O RESTO DO CÓDIGO DESSE BLOCO PHP SÃO TESTES PARA SETAR O TÍTULO DA PÁGINA VIA GET (URL DA PÁGINA)
	  if ($_GET['titulo'] == 'busca') // SE O TÍTULO TIVER SETADO COMO BUSCA, ESCREVER O TÍTULO DE BUSCA
		$titulo = 'RESULTADO DA BUSCA POR: ' . strtoupper($_GET['busca']);
	  
	  elseif ($_GET['titulo'] == 'categorias') { // SE NÃO FOR BUSCA, VERIFICA SE FOI UMA CHAMADA DE CATEGORIAS PELO MENU
		$query = 'SELECT * FROM categorias WHERE codigo = ' . $_GET['categoria'];
		$resultado = mysqli_query($conexao, $query);
		$dados = mysqli_fetch_array($resultado);
		$titulo = 'CATEGORIA: ' . strtoupper($dados['descricao']);
	  }
	  else
		$titulo = $_POST['titulo'];
	else
	  $titulo = 'P&Aacute;GINA INICIAL';
?>